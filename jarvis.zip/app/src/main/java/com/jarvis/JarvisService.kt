package com.jarvis

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var onDone: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var mode = "CLAP"
    private var torchOn = false
    @Volatile private var standby = false
    @Volatile private var stopping = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts.language = Locale("es", "ES")
            tts.setPitch(0.85f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { finishSpeech() }
                @Deprecated("Deprecated in Java") override fun onError(id: String?) { finishSpeech() }
            })
        }
    }

    private fun finishSpeech() { main.post { val d = onDone; onDone = null; d?.invoke() } }

    private fun speak(text: String, done: (() -> Unit)? = null) {
        onDone = done
        if (!ttsReady) { finishSpeech(); return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { shutdown(); return START_NOT_STICKY }
        mode = intent?.getStringExtra("mode") ?: mode
        val ch = "jarvis"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch)
            .setContentTitle("Jarvis en espera")
            .setContentText(if (mode == "CLAP") "Aplauda dos veces" else "Diga: Jarvis activate")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, notif)
        startStandby()
        return START_STICKY
    }

    // ---------- ESPERA ----------
    private fun startStandby() {
        if (stopping) return
        standby = true
        if (mode == "CLAP") Thread { clapLoop() }.start() else listenWake()
    }

    /** Detecta 2 picos fuertes separados entre 150 y 900 ms. */
    private fun clapLoop() {
        val sr = 16000
        val buf = ShortArray(1024)
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(AudioRecord.getMinBufferSize(sr,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096))
        rec.startRecording()
        var first = 0L
        var last = 0L
        while (standby && !stopping) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) continue
            var peak = 0
            for (i in 0 until n) peak = maxOf(peak, abs(buf[i].toInt()))
            val now = SystemClock.elapsedRealtime()
            if (peak > CLAP_THRESHOLD && now - last > 120) {
                if (first != 0L && now - first in 150..900) {
                    standby = false
                    rec.stop(); rec.release()
                    main.post { activate() }
                    return
                }
                first = now
                last = now
            }
            if (first != 0L && now - first > 900) first = 0
        }
        rec.stop(); rec.release()
    }

    private fun listenWake() {
        if (!standby || stopping) return
        recognize("en-US", { text ->
            val t = text.lowercase()
            val hit = t.contains("jarvis") &&
                listOf("activate", "activar", "activa", "actívate").any { t.contains(it) }
            if (hit) { standby = false; activate() } else main.postDelayed({ listenWake() }, 300)
        }, { main.postDelayed({ listenWake() }, 800) })
    }

    // ---------- ACTIVACIÓN ----------
    private fun activate() {
        speak("A sus órdenes, Señor. ¿En qué puedo ayudarle?") {
            recognize("es-ES", { handle(it) },
                { speak("No le he escuchado, Señor.") { startStandby() } })
        }
    }

    private fun recognize(lang: String, ok: (String) -> Unit, fail: () -> Unit) {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    ok(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ") ?: "")
                }
                override fun onError(e: Int) = fail()
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3))
        }
    }

    // ---------- COMANDOS ----------
    private fun after(t: String, vararg keys: String): String {
        for (k in keys) { val i = t.indexOf(k); if (i >= 0) return t.substring(i + k.length).trim() }
        return ""
    }

    private fun handle(raw: String) {
        val t = raw.lowercase()
        val reply = when {
            "mensaje" in t || "notificaci" in t -> readInbox()
            "busca" in t || "investiga" in t -> {
                val q = after(t, "buscar en internet", "busca en internet", "buscar", "busca", "investiga")
                    .removePrefix("sobre").removePrefix("en google").trim()
                if (q.isEmpty()) "¿Qué desea que busque, Señor?"
                else { launchIntent(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))); "Buscando $q en internet, Señor." }
            }
            "linterna" in t || "lámpara" in t -> toggleTorch(!("apaga" in t))
            "abre" in t || "abrir" in t -> openApp(after(t, "abrir", "abre"))
            "sube" in t && "volumen" in t -> { vol(AudioManager.ADJUST_RAISE); "Volumen aumentado, Señor." }
            "baja" in t && "volumen" in t -> { vol(AudioManager.ADJUST_LOWER); "Volumen reducido, Señor." }
            "silencio" in t -> { vol(AudioManager.ADJUST_MUTE); "Silenciado, Señor." }
            "wifi" in t || "wi-fi" in t -> { launchIntent(Intent(Settings.ACTION_WIFI_SETTINGS)); "Abriendo ajustes de Wi-Fi." }
            "bluetooth" in t -> { launchIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Abriendo Bluetooth." }
            "hora" in t -> "Son las " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + ", Señor."
            "apágate" in t || "descansa" in t || "adiós" in t || "apagar" in t -> { stopping = true; "Hasta pronto, Señor." }
            else -> "Lo lamento, Señor, no reconozco esa orden."
        }
        speak(reply) { if (stopping) shutdown() else startStandby() }
    }

    private fun readInbox(): String {
        val m = JarvisInbox.latest(5)
        if (m.isEmpty()) return "No tiene mensajes nuevos, Señor."
        val s = "Tiene ${m.size} mensajes recientes, Señor. " + m.joinToString(". ")
        JarvisInbox.clear()
        return s
    }

    private fun launchIntent(i: Intent) = startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun openApp(name: String): String {
        if (name.isBlank()) return "¿Qué aplicación desea abrir, Señor?"
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?: return "No encuentro la aplicación $name, Señor."
        launchIntent(pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!)
        return "Abriendo $name."
    }

    private fun toggleTorch(on: Boolean): String = try {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(cm.cameraIdList[0], on); torchOn = on
        if (on) "Linterna encendida, Señor." else "Linterna apagada."
    } catch (e: Exception) { "No pude acceder a la linterna, Señor." }

    private fun vol(dir: Int) =
        (getSystemService(AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)

    private fun shutdown() {
        stopping = true; standby = false
        recognizer?.destroy()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }

    companion object { const val CLAP_THRESHOLD = 18000 }
}
