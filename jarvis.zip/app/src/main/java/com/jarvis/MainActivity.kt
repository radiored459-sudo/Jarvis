package com.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
            setBackgroundColor(0xFF0A0F1A.toInt())
        }
        root.addView(TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 32f
            setTextColor(0xFF4FC3F7.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 64)
        })
        fun btn(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        btn("1. Permisos (micrófono)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("2. Acceso a notificaciones (mensajes)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("3. Mostrar sobre otras apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Activar: 2 aplausos") { start("CLAP") }
        btn("Activar: voz \"Jarvis activate\"") { start("VOICE") }
        btn("Apagar Jarvis") {
            startService(Intent(this, JarvisService::class.java).setAction("STOP"))
        }
        setContentView(root)
    }

    private fun start(mode: String) {
        startForegroundService(Intent(this, JarvisService::class.java).putExtra("mode", mode))
    }
}
