package com.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object JarvisInbox {
    val items = ArrayDeque<String>()
    @Synchronized fun add(s: String) {
        items.addFirst(s)
        while (items.size > 20) items.removeLast()
    }
    @Synchronized fun latest(n: Int) = items.take(n)
    @Synchronized fun clear() = items.clear()
}

class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (sbn.packageName == packageName) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val cat = n.category
        if (cat != Notification.CATEGORY_MESSAGE && cat != Notification.CATEGORY_EMAIL &&
            cat != Notification.CATEGORY_SOCIAL) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        JarvisInbox.add("$title dice: $text")
    }
}
